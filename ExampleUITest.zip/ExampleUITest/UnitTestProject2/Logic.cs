﻿using System;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestStack.White;
using TestStack.White.UIItems.WindowItems;
using TestStack.White.UIItems.MenuItems;
using TestStack.White.UIItems;
using TestStack.White.UIItems.Finders;
using TestStack.White.InputDevices;
//using Microsoft.VisualBasic.dll;
using Microsoft.VisualBasic;

namespace UnitTestProject2
{
    [TestClass]
    public class Logic
    {
        private string appPathUnderTest = @"C:\Users\kcunningham20\Desktop\SpeedCrunch";
        private string appUnderTest = @"speedcrunch.exe";
        private string windowPrefix = "SpeedCrunch";
        private string[] menuFileExit = { "Session", "Quit" };
        private string appPathUnderTest2 = @"C:\windows\system32";
        private string appUnderTest2 = @"notepad.exe";
        private string windowPrefix2 = "Untitled ";
        private string[] menuFileExit2 = { "File", "Exit" };

        class AppUnderTest2
        {
            public Application app2;
            public Window w2;
        }
    
        class AppUnderTest
        {
            public Application app;
            public Window w;
        }

        AppUnderTest aut;
        AppUnderTest2 aut2;

        [TestInitialize]
        public void Init()
        {
            aut = StartApp();
        }

        [TestCleanup]
        public void Cleanup()
        {
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.CONTROL);
            aut.w.Keyboard.Enter("N");
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.CONTROL);
            TerminateApp(aut);
        }

        //TestSuite- Logical
        [TestMethod]
        public void Test_XOR()
        {
            //aut.w.Get<UIItem>("ResultDisplay");
            //InterrogateApp();
            //highlight and save to the clipboard
            aut.w.Keyboard.Enter("bin(xor(0b1010; 0b1111))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);

            aut.w.Mouse.Location = new System.Windows.Point(19, 67);
            aut.w.Mouse.DoubleClick(aut.w.Mouse.Location);

            aut.w.Mouse.Location = new System.Windows.Point(10, 1030);
            aut.w.Mouse.DoubleClick(aut.w.Mouse.Location);
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.CONTROL);
            aut.w.Keyboard.Enter("C");
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.CONTROL);

            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.CONTROL);
            aut.w.Keyboard.Enter("N");
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.CONTROL);

            aut2 = StartApp2();
            if (aut2.w2 != null)
            {
                aut2.w2.Mouse.Location = new System.Windows.Point(600, 600);
                aut2.w2.Mouse.Click();
                aut2.w2.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.CONTROL);
                aut2.w2.Keyboard.Enter("V");
                aut2.w2.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.CONTROL);
            }

            TerminateApp2(aut2);

            //FileStream f = new FileStream("myFile.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
            //StreamReader s = new StreamReader(@"C:\Users\kcunningham20\Documents\myFile.txt");
            string text = System.IO.File.ReadAllText(@"C:\Users\kcunningham20\Documents\myFile.txt");
            //string word = Console.ReadLine();
            Assert.AreEqual(text, "0b101");
        }

        [TestMethod]
        public void Test_XOR_Negative()
        {
            aut.w.Keyboard.Enter("bin(xor(-0b1010; 0b1111))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
        }

        [TestMethod]
        public void Test_NOT()
        {
            aut.w.Keyboard.Enter("bin(not(0b1010))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
        }

        [TestMethod]
        public void Test_NOT_Negative()
        {
            aut.w.Keyboard.Enter("bin(not(-0b1010))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
        }


        [TestMethod]
        public void Test_AND()
        {
            aut.w.Keyboard.Enter("bin(and(0b1010; 0b1111))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
        }

        [TestMethod]
        public void Test_AND_Negative()
        {
            aut.w.Keyboard.Enter("bin(and(-0b1010; 0b1111))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
        }

        [TestMethod]
        public void Test_OR()
        {
            aut.w.Keyboard.Enter("bin(or(0b1010; 0b1111))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
        }

        [TestMethod]
        public void Test_OR_Negative()
        {
            aut.w.Keyboard.Enter("bin(or(-0b1010; 0b1111))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
        }

        [TestMethod]
        public void Test_Bit_Shift_Left()
        {
            aut.w.Keyboard.Enter("bin(shl(0b1010; 2))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
        }

        [TestMethod]
        public void Test_Bit_Shift_Right()
        {
            aut.w.Keyboard.Enter("bin(shr(0b101000; 2))");
            aut.w.Keyboard.HoldKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
            aut.w.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
        }

        private AppUnderTest StartApp()
        {
            AppUnderTest aut = new AppUnderTest();
            var appPath = Path.Combine(appPathUnderTest, appUnderTest);
            aut.app = Application.Launch(appPath);
            var ws = aut.app.GetWindows();
            var start = DateTime.Now;
            var timeout = new TimeSpan(0, 0, 30);
            while ((ws == null || ws.Count == 0) && DateTime.Now - start < timeout)
            {
                ws = aut.app.GetWindows();
            }
            while (aut.w == null && DateTime.Now - start < timeout)
            {
                System.Diagnostics.Debug.Write(".");
                try
                {
                    foreach (var win in ws)
                    {
                        System.Diagnostics.Debug.Write(win.Title);
                        if (win.Title.StartsWith(windowPrefix))
                            aut.w = win;
                    }
                }
                catch
                {
                    //Might end up here if the app has a splash screen, and that window goes away. Refresh the windows list
                    ws = aut.app.GetWindows();
                }
            }

            //maximize window and clicks input box
            try
            {
                if (aut.w != null)
                {
                    var max = aut.w.Get<Button>("Maximize");
                    max.Click();
                    aut.w.Mouse.Location = new System.Windows.Point(10, 1030);
                    aut.w.Click();
                }
            }
            catch
            {
                aut.w.Mouse.Location = new System.Windows.Point(10, 1030);
                aut.w.Click();
            }

            return aut;
        }

        private void TerminateApp(AppUnderTest aut)
        {
            //if (aut.w.MenuBar != null)
            //{
            //    var m = aut.w.MenuBar.MenuItem();
            //    if (m != null)
            //    {
            //        m.Click();
            //    }
            //}
            //else
            //{
            aut.w.Close();
            //}

            //DontSave(aut);
        }
        /*
        private void DontSave(AppUnderTest aut)
        {
            //Check for "Save Document?" dialog
            try
            {
                Window dialog = null;
                while (dialog == null)
                {
                    var ws = aut.app.GetWindows();
                    foreach (var w in ws)
                    {
                        if (w.Title.StartsWith("SpeedCrunch"))
                            dialog = w;
                    }
                }
                //var b = dialog.Get<Button>("Don't Save");
                //b.Click();
            }
            catch
            {
                //Window went away. Do nothing
            }
        }
        */
        private void InterrogateApp()
        {
            AppUnderTest2 aut = StartApp2();

            if (aut.w2 != null)
            {
                InterrogateItem(aut.w2);
                TerminateApp2(aut);
            }
        }

        private void InterrogateItem(Window w)
        {
            InterrogateItem(w, w);
        }

        private void InterrogateItem(Window w, IUIItem i)
        {
            System.Diagnostics.Debug.Print(i.ToString());
            w.Mouse.Location = new System.Windows.Point(i.Bounds.Left + i.Bounds.Width / 2, i.Bounds.Top + i.Bounds.Height / 2);

            if (i is UIItemContainer)
            {
                var ic = i as UIItemContainer;
                foreach (var mb in ic.MenuBars)
                {
                    System.Diagnostics.Debug.Print(mb.ToString());

                    w.Mouse.Location = new System.Windows.Point(mb.Bounds.Left + mb.Bounds.Width / 2, mb.Bounds.Top + mb.Bounds.Height / 2);

                }

                foreach (var x in ic.Items)
                {
                    InterrogateItem(w, x);

                    w.Mouse.Location = new System.Windows.Point(x.Bounds.Left + x.Bounds.Width / 2, x.Bounds.Top + x.Bounds.Height / 2);
                }
            }
        }

        private AppUnderTest2 StartApp2()
        {
            AppUnderTest2 aut2 = new AppUnderTest2();
            var appPath2 = Path.Combine(appPathUnderTest2, appUnderTest2);
            aut2.app2 = Application.Launch(appPath2);
            var ws2 = aut2.app2.GetWindows();
            var start2 = DateTime.Now;
            var timeout2 = new TimeSpan(0, 0, 30);
            while ((ws2 == null || ws2.Count == 0) && DateTime.Now - start2 < timeout2)
            {
                ws2 = aut2.app2.GetWindows();
            }
            while (aut2.w2 == null && DateTime.Now - start2 < timeout2)
            {
                System.Diagnostics.Debug.Write(".");
                try
                {
                    foreach (var win2 in ws2)
                    {
                        System.Diagnostics.Debug.Write(win2.Title);
                        if (win2.Title.StartsWith(windowPrefix2))
                            aut2.w2 = win2;
                    }
                }
                catch
                {
                    //Might end up here if the app has a splash screen, and that window goes away. Refresh the windows list
                    ws2 = aut2.app2.GetWindows();
                }
            }

            return aut2;
        }

        private void TerminateApp2(AppUnderTest2 aut2)
        {
            if (aut2.w2.MenuBar != null)
            {
                var m2 = aut2.w2.MenuBar.MenuItem(menuFileExit2);
                if (m2 != null)
                {
                    m2.Click();
                }
            }
            else
            {
                aut2.w2.Close();
            }

            Save2(aut2);

        }

        private void Save2(AppUnderTest2 aut2)
        {
            //Check for "Save Document?" dialog
            try
            {
                Window dialog2 = null;
                while (dialog2 == null)
                {
                    var ws2 = aut2.app2.GetWindows();
                    foreach (var w2 in ws2)
                    {
                        if (w2.Title.StartsWith("Notepad"))
                            dialog2 = w2;
                    }
                }

                var b = dialog2.Get<Button>("Save");
                b.Click();
                b.KeyIn(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);
                //aut2.w2.Keyboard.LeaveKey(TestStack.White.WindowsAPI.KeyboardInput.SpecialKeys.RETURN);

                Window dialog3 = null;
                while (dialog3 == null)
                {
                    var ws3 = aut2.app2.GetWindows();
                    foreach (var w2 in ws3)
                    {
                        if (w2.Title.StartsWith("Save As"))
                            dialog3 = w2;
                    }
                }
                var b2 = dialog3.Get<TextBox>("File name:");
                b2.Enter("myFile.txt");
                //b2.("myFile.txt");
                var b3 = dialog3.Get<Button>("Save");
                b3.Click();

                Window dialog4 = null;
                while (dialog4 == null)
                {
                    var ws4 = aut2.app2.GetWindows();
                    foreach (var w2 in ws4)
                    {
                        if (w2.Title.StartsWith("Confirm Save As"))
                            dialog4 = w2;
                    }
                }
                var b4 = dialog4.Get<Button>("Yes");
                b4.Click();
                var m2 = aut2.w2.MenuBar.MenuItem(menuFileExit2);
                if (m2 != null)
                {
                    m2.Click();
                }


           
            }
            catch
            {
                //Window went away. Do nothing
            }
        }
    }
}
